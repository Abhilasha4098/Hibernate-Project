package Util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

    private static SessionFactory sessionFactory;

    static {
        try {
            // Initialize the SessionFactory using hibernate.cfg.xml
            sessionFactory = new Configuration()
                    .configure("hibernate.cfg.xml") // Load configuration from XML
                    .addAnnotatedClass(model.Donor.class) // Add entity class mappings
                    .addAnnotatedClass(model.Donation.class)
                    .addAnnotatedClass(model.DonationType.class)
                    .buildSessionFactory();
        } catch (Exception e) {
            System.err.println("Error initializing SessionFactory: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}

