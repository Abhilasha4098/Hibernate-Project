package dao;

import model.Donor;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Util.HibernateUtil;

import java.util.List;

public class DonorDAO {

    public void saveDonor(Donor donor) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.save(donor);
        transaction.commit();
        session.close();
    }

    public List<Donor> getAllDonors() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Donor> donors = session.createQuery("from Donor", Donor.class).list();
        session.close();
        return donors;
    }

    public Donor getDonorById(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Donor donor = session.get(Donor.class, id);
        session.close();
        return donor;
    }

    public void updateDonor(Donor donor) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.update(donor);
        transaction.commit();
        session.close();
    }

    public void deleteDonor(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        Donor donor = session.get(Donor.class, id);
        if (donor != null) {
            session.delete(donor);
        }
        transaction.commit();
        session.close();
    }
}
