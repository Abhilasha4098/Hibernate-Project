package dao;

import model.DonationType;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Util.HibernateUtil;

import java.util.List;

public class DonationTypeDAO {

    // Save a new donation type
    public void saveDonationType(DonationType donationType) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.save(donationType);
        transaction.commit();
        session.close();
    }

    // Retrieve all donation types
    public List<DonationType> getAllDonationTypes() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<DonationType> donationTypes = session.createQuery("from DonationType", DonationType.class).list();
        session.close();
        return donationTypes;
    }

    // Retrieve a donation type by ID
    public DonationType getDonationTypeById(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        DonationType donationType = session.get(DonationType.class, id);
        session.close();
        return donationType;
    }

    // Update an existing donation type
    public void updateDonationType(DonationType donationType) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.update(donationType);
        transaction.commit();
        session.close();
    }

    // Delete a donation type by ID
    public void deleteDonationType(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        DonationType donationType = session.get(DonationType.class, id);
        if (donationType != null) {
            session.delete(donationType);
        }
        transaction.commit();
        session.close();
    }
}
