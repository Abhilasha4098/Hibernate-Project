package dao;

import model.Donation;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Util.HibernateUtil;

import java.util.List;

public class DonationDAO {

    public void saveDonation(Donation donation) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.save(donation);
        transaction.commit();
        session.close();
    }

    public List<Donation> getAllDonations() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Donation> donations = session.createQuery("from Donation", Donation.class).list();
        session.close();
        return donations;
    }

    public Donation getDonationById(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Donation donation = session.get(Donation.class, id);
        session.close();
        return donation;
    }

    public void updateDonation(Donation donation) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.update(donation);
        transaction.commit();
        session.close();
    }

    public void deleteDonation(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        Donation donation = session.get(Donation.class, id);
        if (donation != null) {
            session.delete(donation);
        }
        transaction.commit();
        session.close();
    }

    // Additional method for searching donations by amount range
    public List<Donation> getDonationsByAmountRange(double minAmount, double maxAmount) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Donation> donations = session.createQuery("from Donation where amount between :minAmount and :maxAmount", Donation.class)
                                          .setParameter("minAmount", minAmount)
                                          .setParameter("maxAmount", maxAmount)
                                          .list();
        session.close();
        return donations;
    }
}
