

import dao.DonorDAO;
import dao.DonationDAO;
import dao.DonationTypeDAO;
import model.Donor;
import model.Donation;
import model.DonationType;

import java.util.List;
import java.util.Scanner;

import Util.HibernateUtil;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static DonorDAO donorDAO = new DonorDAO();
    private static DonationDAO donationDAO = new DonationDAO();
    private static DonationTypeDAO donationTypeDAO = new DonationTypeDAO();

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("************* Donor Management System *************");
            System.out.println("1. Add Donor");
            System.out.println("2. List All Donors");
            System.out.println("3. Update Donor");
            System.out.println("4. Delete Donor");
            System.out.println("5. Add Donation");
            System.out.println("6. List All Donations");
            System.out.println("7. Add Donation Type");
            System.out.println("8. List All Donation Types");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline left-over

            switch (choice) {
                case 1:
                    addDonor();
                    break;
                case 2:
                    listDonors();
                    break;
                case 3:
                    updateDonor();
                    break;
                case 4:
                    deleteDonor();
                    break;
                case 5:
                    addDonation();
                    break;
                case 6:
                    listDonations();
                    break;
                case 7:
                    addDonationType();
                    break;
                case 8:
                    listDonationTypes();
                    break;
                case 9:
                    HibernateUtil.shutdown();
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 9);
    }

    private static void addDonor() {
        System.out.print("Enter donor name: ");
        String name = scanner.nextLine();

        System.out.print("Enter donor email: ");
        String email = scanner.nextLine();

        System.out.print("Enter donor phone: ");
        String phone = scanner.nextLine();

        System.out.print("Enter donor address: ");
        String address = scanner.nextLine();

        Donor donor = new Donor();
        donor.setName(name);
        donor.setEmail(email);
        donor.setPhone(phone);
        donor.setAddress(address);
        donor.setRegistrationDate(new java.util.Date());
        donor.setActive(true); // default to active

        donorDAO.saveDonor(donor);
        System.out.println("Donor added successfully.");
    }

    private static void listDonors() {
        List<Donor> donors = donorDAO.getAllDonors();
        if (donors.isEmpty()) {
            System.out.println("No donors found.");
        } else {
            for (Donor donor : donors) {
                System.out.println("ID: " + donor.getId() + ", Name: " + donor.getName() +
                        ", Email: " + donor.getEmail() + ", Active: " + donor.isActive());
            }
        }
    }

    private static void updateDonor() {
        System.out.print("Enter donor ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Donor donor = donorDAO.getDonorById(id);
        if (donor != null) {
            System.out.print("Enter new name (Leave blank to keep existing): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) donor.setName(name);

            System.out.print("Enter new email (Leave blank to keep existing): ");
            String email = scanner.nextLine();
            if (!email.isEmpty()) donor.setEmail(email);

            System.out.print("Enter new phone (Leave blank to keep existing): ");
            String phone = scanner.nextLine();
            if (!phone.isEmpty()) donor.setPhone(phone);

            System.out.print("Enter new address (Leave blank to keep existing): ");
            String address = scanner.nextLine();
            if (!address.isEmpty()) donor.setAddress(address);

            donorDAO.updateDonor(donor);
            System.out.println("Donor updated successfully.");
        } else {
            System.out.println("Donor not found.");
        }
    }

    private static void deleteDonor() {
        System.out.print("Enter donor ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        donorDAO.deleteDonor(id);
        System.out.println("Donor deleted successfully.");
    }

    private static void addDonation() {
        System.out.print("Enter donor ID for the donation: ");
        int donorId = scanner.nextInt();

        Donor donor = donorDAO.getDonorById(donorId);
        if (donor != null) {
            System.out.print("Enter donation amount: ");
            double amount = scanner.nextDouble();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter donation type ID: ");
            int typeId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            DonationType donationType = donationTypeDAO.getDonationTypeById(typeId);
            if (donationType != null) {
                Donation donation = new Donation();
                donation.setAmount(amount);
                donation.setDonor(donor);
                donation.setDonationType(donationType);
                donation.setDonationDate(new java.util.Date());
                donation.setTransactionId("TXN" + System.currentTimeMillis());
                donation.setStatus("Completed");

                donationDAO.saveDonation(donation);
                System.out.println("Donation added successfully.");
            } else {
                System.out.println("Donation type not found.");
            }
        } else {
            System.out.println("Donor not found.");
        }
    }

    private static void listDonations() {
        List<Donation> donations = donationDAO.getAllDonations();
        if (donations.isEmpty()) {
            System.out.println("No donations found.");
        } else {
            for (Donation donation : donations) {
                System.out.println("Donation ID: " + donation.getId() + ", Amount: " + donation.getAmount() +
                        ", Donor: " + donation.getDonor().getName() + ", Type: " + donation.getDonationType().getTypeName());
            }
        }
    }

    private static void addDonationType() {
        System.out.print("Enter donation type name: ");
        String typeName = scanner.nextLine();

        System.out.print("Enter donation type description: ");
        String description = scanner.nextLine();

        DonationType donationType = new DonationType();
        donationType.setTypeName(typeName);
        donationType.setDescription(description);

        donationTypeDAO.saveDonationType(donationType);
        System.out.println("Donation type added successfully.");
    }

    private static void listDonationTypes() {
        List<DonationType> donationTypes = donationTypeDAO.getAllDonationTypes();
        if (donationTypes.isEmpty()) {
            System.out.println("No donation types found.");
        } else {
            for (DonationType type : donationTypes) {
                System.out.println("ID: " + type.getId() + ", Name: " + type.getTypeName() +
                        ", Description: " + type.getDescription());
            }
        }
    }
}
